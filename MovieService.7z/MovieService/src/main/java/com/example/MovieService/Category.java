package com.example.MovieService;

public enum Category {
    Akcja,
    Komedia,
    Bajka,
    Dramat;
}
