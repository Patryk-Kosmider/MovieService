package com.example.MovieService;

import java.util.Objects;

public class Movie {
    private String ID;
    private String name;
    private String category;

    public Movie(String ID, String name, String category) throws MovieNoIdGivenException {
        if(Objects.equals(ID, "")){
            throw new MovieNoIdGivenException();
        } else {
            this.ID = ID;
        }
        this.name = name;
        this.category = category;
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }
}
