package com.example.MovieService;

import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/base")
public class MovieController {

    private final MovieService movieService;

    public MovieController(MovieService movieService) {
        this.movieService = movieService;
    }

    @GetMapping("/movies")
    public ResponseEntity<List<Movie>> getMovieList(){
        return ResponseEntity.ok(movieService.getMovieList());
    }

    @GetMapping("/movies/{id}")
    public ResponseEntity<Movie> getMovieById(@PathVariable String id) throws MovieNotFoundException {
            return ResponseEntity.ok(movieService.getMovieByID(id));
        }

    @PostMapping("/movies")
    public ResponseEntity<Movie> addNewMovie(@RequestBody Movie movie){
        movieService.addNewMovie(movie);
        return ResponseEntity.ok(movie);
    }
    @PutMapping("/movies{id}")
    public ResponseEntity<Movie> updateMovie(@PathVariable String id, @RequestBody Movie movie) throws MovieNotFoundException {
        Movie movie_update = movieService.getMovieByID(id);
        movie_update.setID(movie.getID());
        movie_update.setName(movie.getName());
        movie_update.setCategory(movie.getCategory());
        return ResponseEntity.ok(movie_update);
    }

    @DeleteMapping("/movies/{id}")
    public ResponseEntity<Void> deleteMovie(@PathVariable String id) throws MovieNotFoundException {
        movieService.deleteMovie(id);
        return ResponseEntity.ok().build();
    }
}
