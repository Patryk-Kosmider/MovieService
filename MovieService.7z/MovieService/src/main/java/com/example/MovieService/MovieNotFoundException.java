package com.example.MovieService;

public class MovieNotFoundException extends Exception{
    public MovieNotFoundException(String error_msg){
        super(error_msg);
    }
}
