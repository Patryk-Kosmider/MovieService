package com.example.MovieService;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/base")
public class MovieController {

    private final MovieServices movieService;

    public MovieController(MovieServices movieService) {
        this.movieService = movieService;
    }

    @GetMapping("/movies")
    public ResponseEntity<List<Movie>> getMovieList(){
        return ResponseEntity.ok(movieService.getAll());
    }

    @GetMapping("/movies/{id}")
    public ResponseEntity<Movie> getMovieById(@PathVariable int id) throws MovieNotFoundException {
            return ResponseEntity.ok(movieService.findById(id));
        }

    @PatchMapping("/movies{id}")
    public ResponseEntity<Movie> updateMovie(@RequestParam int id, @RequestBody Movie movie){
        Movie movie_update = movieService.updateMovie(movie, id);
        return ResponseEntity.ok(movie_update);
    }

    @PostMapping("/movies")
    public ResponseEntity<Movie> addNewMovie(@RequestBody Movie movie){
        movieService.addNewMovie(movie);
        return ResponseEntity.ok(movie);
    }

    @DeleteMapping("/movies/{id}")
    public ResponseEntity<Void> deleteMovie(@PathVariable int id){
        movieService.deleteMovieById(id);
        return ResponseEntity.ok().build();
    }

    @PatchMapping("/movies/{id}/available")
    public ResponseEntity<Movie> updateAvailable(@PathVariable int id) throws MovieNotFoundException {
        Movie movie = movieService.updateIsAvailable(id);
        return ResponseEntity.ok(movie);
    }

}
