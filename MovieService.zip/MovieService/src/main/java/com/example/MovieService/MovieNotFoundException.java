package com.example.MovieService;

public class MovieNotFoundException extends Exception{
    public MovieNotFoundException(){
    }
}
